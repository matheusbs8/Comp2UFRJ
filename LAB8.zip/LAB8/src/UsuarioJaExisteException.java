//Nome: Matheus Barroso de Santana
//DRE: 120041661
public class UsuarioJaExisteException extends Exception {
}
