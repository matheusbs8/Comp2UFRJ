//Nome: Matheus Barroso de Santana
//DRE: 120041661
public class TamanhoZeradoException extends Exception {
}
